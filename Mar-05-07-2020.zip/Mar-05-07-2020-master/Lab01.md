* Build a Spring Boot Web application __(Lab01)__ that takes the name of the movie as input

* The movie name is pushed to a Queue [X]

* A backend service will continuously poll for new entries in the Queue [X] and pass them on to __**http://www.omdbapi.com/?i=tt3896198&apikey=52d1c7f&t=moviename**__ (Read the documentation for JSON response you get) and fetch the star cast and directors information
* For example go to __http://www.omdbapi.com/?i=tt3896198&apikey=52d1c7f&t=Dabangg__

* The movie data is stored in another Queue [Y]

* The __Lab01__ has a page(/details) that displays all the movie details you have requested so far. Everytime you hit the endpoint __/details__ it displays list of all movies and their details in the page

* Design your own Queues and applications

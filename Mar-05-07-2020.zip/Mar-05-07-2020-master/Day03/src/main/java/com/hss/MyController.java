package com.hss;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class MyController {

	Logger logger = LoggerFactory.getLogger(MyController.class);

	@Autowired
	private MyService myService;
	
	private RestTemplate restTemplate = new RestTemplate();
	
	@GetMapping("/square/{num}")
	@HystrixCommand(fallbackMethod = "computeSquareFallback")
	public String computeSquare(@PathVariable int num) {
		logger.info("computeSquare called with {}", num);
		String url = "http://localhost:8083/square/" + num;
		ResponseEntity<Integer> response = restTemplate.getForEntity(url, Integer.class);
		return "Square " + response.getBody();
	}
	
	public String computeSquareFallback(int num) {
		return "Square service is down"; 
	}
	
	
	
	@GetMapping("/hello/{name}")
	public String hello(@PathVariable String name) {
		logger.info("hello called with {}", name);
		return myService.sayHello(name);
	}
}

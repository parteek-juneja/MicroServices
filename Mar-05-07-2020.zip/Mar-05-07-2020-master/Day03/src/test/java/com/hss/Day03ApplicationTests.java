package com.hss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day03ApplicationTests {

	@Test
	void contextLoads() {
	}

}

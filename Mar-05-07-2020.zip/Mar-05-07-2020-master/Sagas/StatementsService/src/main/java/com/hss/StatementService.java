package com.hss;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class StatementService {

	
	@Autowired
	private StatementRepository statementRepository;
	
	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Value("${queue.statement}")
	private String statementQueue;
	
	
	@JmsListener(destination = "${queue.account}")
	public void receiveAccountsInfo(String message) {
		System.out.println("***** receiveAccountsInfo "  + message);
		//String message = accountNumber + "," + amount + "," + "deposit," + type;
		String[] messageArr = message.split(",");
		int accountNumber = Integer.parseInt(messageArr[0]);
		int amount = Integer.parseInt(messageArr[1]);
		String operation = messageArr[2];
		String type = messageArr[3];
		try {
			insert(accountNumber, amount, type);
			message +=  ",COMPLETE";
		} catch (Exception e) {
			System.out.println("ERROR: " + e.getMessage());
			message +=  ",FAILED";
		}
		
		jmsTemplate.convertAndSend(statementQueue, message);
	}
	
	
	public void insert(int accountNumber, int amount, String type) {
		Statement statement = new Statement();
		statement.setAccountNumber(accountNumber);
		statement.setAmount(amount);
		statement.setType(type);
		statementRepository.save(statement);
	}
}

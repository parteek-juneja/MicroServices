package com.hss;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Value("${queue.account}")
	private String accountQueue;
	
	
	@JmsListener(destination = "${queue.statement}")
	public void receiveStatementsInfo(String message) {
		System.out.println("***** receiveStatementsInfo "  + message);
		//String message = accountNumber + "," + amount + "," + "deposit," + type + ",COMPLETE";
		String[] messageArr = message.split(",");
		int accountNumber = Integer.parseInt(messageArr[0]);
		int amount = Integer.parseInt(messageArr[1]);
		String operation = messageArr[2];
		String outcome = messageArr[4];
		
		Account account = accountRepository
				.findById(accountNumber)
				.orElseThrow(RuntimeException::new);
		if("COMPLETE".equalsIgnoreCase(outcome)) {
			if("deposit".equalsIgnoreCase(operation)) {
				account.setBalance(account.getBalance() + amount);
			}
			else {
				account.setBalance(account.getBalance() - amount);
			}
			account.setTransactionStatus("COMPLETE");
			accountRepository.save(account);
		}
		else {
			account.setTransactionStatus("FAILED");
			accountRepository.save(account);
		}
	}
	
	
	
	@Transactional
	public boolean deposit(int accountNumber, int amount, String type) {
		Account account = accountRepository
					.findById(accountNumber)
					.orElseThrow(RuntimeException::new);
		
		account.setTransactionStatus("IN_PROGRESS");
		accountRepository.save(account);
		
		//Can be in JSON too. Using csv for simplicity
		String message = accountNumber + "," + amount + "," + "deposit," + type;
		jmsTemplate.convertAndSend(accountQueue, message);
		
		return true;
	}
	
	@Transactional
	public boolean withdraw(int accountNumber, int amount, String type) {
		Account account = accountRepository
					.findById(accountNumber)
					.orElseThrow(RuntimeException::new);
		account.setTransactionStatus("IN_PROGRESS");
		accountRepository.save(account);

		//Can be in JSON too. Using csv for simplicity
		String message = accountNumber + "," + amount + "," + "deposit," + type;
		jmsTemplate.convertAndSend(accountQueue, message);

		return false;
	}
}

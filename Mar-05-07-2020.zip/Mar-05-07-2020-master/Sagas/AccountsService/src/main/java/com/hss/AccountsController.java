package com.hss;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountsController {

	@Autowired
	private AccountService accountService;
	
	@PutMapping("/account")
	public String compute(@RequestParam("accountnumber") int accountNumber, 
			@RequestParam int amount, @RequestParam String type, @RequestParam String operation) {
		if(operation.equalsIgnoreCase("deposit")) {
			accountService.deposit(accountNumber, amount, type);	
		}
		else if(operation.equalsIgnoreCase("withdraw")) {
			accountService.withdraw(accountNumber, amount, type);	
		}
		
		return "IN PROGRESS";
	}
}

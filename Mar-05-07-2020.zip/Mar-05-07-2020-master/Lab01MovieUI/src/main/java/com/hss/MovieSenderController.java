package com.hss;

import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MovieSenderController {

	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Autowired
	private Map<String, String> movieDetailsStore;
	
	@Value("${movie.queue}")
	private String movieQueue;
	
	@GetMapping("/moviedetails/{moviename}")
	public String getMovieDetails(@PathVariable("moviename") String movieName) {
		return movieDetailsStore.get(movieName.toLowerCase());
	}
	
	
	@GetMapping("/details")
	public Map<String, String> getMovieDetailsStore() {
		return movieDetailsStore;
	}
	
	@JmsListener(destination = "${movie.details.queue}")
	public void loadMovieDetails(String details) {
		JSONObject jsonObject = new JSONObject(details);
		String title = (String)jsonObject.get("Title");
		movieDetailsStore.put(title.toLowerCase(), details);
	}
	
	@GetMapping("/movie/{moviename}")
	public String pushMovieDetails(@PathVariable("moviename") String movieName) {
		jmsTemplate.convertAndSend(movieQueue, movieName);
		movieDetailsStore.put(movieName.toLowerCase(), "");
		return "Fetching details";
	}
	
	
	
	
	
	
	
	
	
	
	
	
}

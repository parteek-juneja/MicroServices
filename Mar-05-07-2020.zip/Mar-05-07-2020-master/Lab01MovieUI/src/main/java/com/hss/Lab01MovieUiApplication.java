package com.hss;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
//@Configuration
public class Lab01MovieUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab01MovieUiApplication.class, args);
	}
	
	@Bean
	public Map<String, String> movieDetailsStore() {
		return new HashMap<>();
	}

}

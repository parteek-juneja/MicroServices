package com.hss;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class MathController {

	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${square.service.base.url}")
	private String squareServiceBaseUrl;
	
	@PostMapping("/math/square/{num}")
	//@HystrixCommand(fallbackMethod = "findSquareFallback")
	public String findSquare(@PathVariable long num) {
		System.out.println("****** in findSquare method");
		String url = squareServiceBaseUrl + "/" + num;
		System.out.println(url);
		ResponseEntity<Long> response = restTemplate.getForEntity(url, Long.class);
		return response.getBody() + "";
	}
	
	public String findSquareFallback(long num) {
		System.out.println("----- in findSquareFallback method");
		return "Oops!!! Something has gone wrong. Please try later";
	}
}











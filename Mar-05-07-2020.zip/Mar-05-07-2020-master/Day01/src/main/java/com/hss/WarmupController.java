package com.hss;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class WarmupController {

	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${day01.service.url}")
	private String day01ServiceUrl;
	
	@GetMapping("/welcome")
	public String warmUp() {
		ResponseEntity<String> response = restTemplate.getForEntity(day01ServiceUrl, String.class);
		return response.getBody();
	}
}
